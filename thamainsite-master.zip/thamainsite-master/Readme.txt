"ajax.googleapis.com" had dossier dial
ajax bibs 

site rah kayn f "main_site"
radi tl9a readme tem