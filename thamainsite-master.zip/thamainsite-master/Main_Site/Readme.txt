Homepage kayna f index.html rah fiha 
comments ila bghayti tbdl

assets fiha js scripts dyal slider o fiha
images o css dyal splider o normalize

css rah fiha main style.scss

fonts rah fiha lfonts bayna 

ila bdlto chi 7aja Gouloha liya bach 
tkoun lkhedma mtnas9a 

peaaace!!!